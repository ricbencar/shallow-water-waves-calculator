package com.example.weibull

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.v2.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextReplacement
import androidx.test.espresso.Espresso.pressBack
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WeibullTheoryNavigationTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun theoryLink_opensDetailedTheory_andVisibleBackActionReturnsToCalculator() {
        composeRule.onNodeWithTag("weibull_theory_link")
            .performScrollTo()
            .performClick()

        val theory = composeRule.onNodeWithTag("theory_screen").assertIsDisplayed()
        val compositeSection = hasText(
            text = "Composite Weibull distribution",
            substring = true,
            ignoreCase = true,
        )
        theory.performScrollToNode(compositeSection)
        composeRule.onNode(compositeSection).assertIsDisplayed()

        theory.performScrollToNode(hasTestTag("theory_back"))
        composeRule.onNodeWithTag("theory_back")
            .assertIsDisplayed()
            .performClick()

        composeRule.onNodeWithTag("weibull_theory_link").assertIsDisplayed()
    }

    @Test
    fun theory_exposesAppliedFormulaAndLimitations_andBackPreservesCalculatorInput() {
        val significantWaveHeight = composeRule.onAllNodes(hasSetTextAction())[0]
        significantWaveHeight.performTextReplacement("3.25")

        composeRule.onNodeWithTag("weibull_theory_link")
            .performScrollTo()
            .performClick()

        val theory = composeRule.onNodeWithTag("theory_screen")
        theory.performScrollToNode(hasText("Q(H)", substring = true))
        composeRule.onNodeWithText("Q(H)", substring = true).assertIsDisplayed()

        theory.performScrollToNode(hasTestTag("theory_limitations"))
        composeRule.onNodeWithTag("theory_limitations").assertIsDisplayed()
        composeRule.onNodeWithText(
            text = "Applicability and limitations",
            substring = true,
            ignoreCase = true,
        ).fetchSemanticsNode()

        pressBack()

        composeRule.onNodeWithTag("weibull_theory_link").assertIsDisplayed()
        composeRule.onAllNodes(hasSetTextAction())[0]
            .assertTextContains("3.25", substring = true)
    }
}
