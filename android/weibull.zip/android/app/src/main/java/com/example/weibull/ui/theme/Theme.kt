package com.example.weibull.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = OceanBlue,
    onPrimary = Color.White,
    primaryContainer = OceanPrimaryContainer,
    onPrimaryContainer = OceanNavy,
    secondary = OceanTeal,
    onSecondary = Color.White,
    secondaryContainer = OceanSecondaryContainer,
    onSecondaryContainer = OceanText,
    tertiary = OceanAmber,
    onTertiary = Color(0xFF3E2100),
    background = OceanBackground,
    onBackground = OceanText,
    surface = OceanSurface,
    onSurface = OceanText,
    surfaceVariant = OceanSurfaceVariant,
    onSurfaceVariant = OceanMutedText,
    outline = OceanOutline,
    outlineVariant = OceanOutlineVariant,
    error = OceanError,
    onError = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = OceanDarkPrimary,
    onPrimary = Color(0xFF003547),
    primaryContainer = Color(0xFF004D66),
    onPrimaryContainer = Color(0xFFC4E9F8),
    secondary = OceanDarkSecondary,
    onSecondary = Color(0xFF003733),
    secondaryContainer = Color(0xFF00504A),
    onSecondaryContainer = Color(0xFF9AF3E8),
    background = OceanDarkBackground,
    onBackground = OceanDarkText,
    surface = OceanDarkSurface,
    onSurface = OceanDarkText,
    surfaceVariant = OceanDarkSurfaceVariant,
    onSurfaceVariant = OceanDarkMutedText,
    outline = OceanDarkOutline,
    outlineVariant = OceanDarkOutlineVariant,
    error = OceanDarkError,
    onError = Color(0xFF690005),
)

@Composable
fun WeibullTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = WeibullTypography,
        content = content,
    )
}
