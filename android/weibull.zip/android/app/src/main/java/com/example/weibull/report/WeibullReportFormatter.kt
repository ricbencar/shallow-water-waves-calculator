package com.example.weibull.report

import com.example.weibull.solver.WaveAnalysisResult
import java.util.Locale

object WeibullReportFormatter {
    fun format(result: WaveAnalysisResult): String = buildString {
        appendLine("======================")
        appendLine("   INPUT PARAMETERS")
        appendLine("======================")
        appendLine("Hm0 (m)         : ${number(result.input.hm0)}")
        appendLine("d (m)           : ${number(result.input.waterDepth)}")
        appendLine(
            "Beach slope (m) : ${number(result.input.slopeDenominator)}   " +
                "(tan(alpha) = ${number(result.tanAlpha)})",
        )
        appendLine()
        appendLine("Distribution Used : ${result.distribution.displayName}")
        appendLine()
        appendLine("===========================")
        appendLine("   CALCULATED PARAMETERS")
        appendLine("===========================")
        appendLine("Free-surface variance m0 (m^2)   : ${number(result.freeSurfaceVariance)}")
        appendLine("Mean square wave height Hrms (m) : ${number(result.hrms)}")
        appendLine("Transitional wave height Htr (m) : ${number(result.transitionHeightMeters)}")
        appendLine("Dimensionless H~_tr (Htr/Hrms)   : ${number(result.normalizedTransitionHeight)}")
        appendLine()
        appendLine("=========================================")
        appendLine("   DIMENSIONLESS WAVE HEIGHTS (H/Hrms)")
        appendLine("=========================================")
        appendLine("H1/Hrms       : ${number(result.lowerScaleToHrms)}")
        appendLine("H2/Hrms       : ${number(result.upperScaleToHrms)}")
        result.statistics.forEach { statistic ->
            val paddedLabel = when (statistic.denominator) {
                3 -> "H1/3 / Hrms  "
                10 -> "H1/10 / Hrms "
                50 -> "H1/50 / Hrms "
                100 -> "H1/100 / Hrms"
                250 -> "H1/250 / Hrms"
                else -> "H1/1000 /Hrms"
            }
            appendLine("$paddedLabel : ${number(statistic.ratioToHrms)}")
        }
        appendLine()
        appendLine("==================================")
        appendLine("   DIMENSIONAL WAVE HEIGHTS (m)")
        appendLine("==================================")
        appendLine("H1 (m)        : ${number(result.lowerScaleMeters)}")
        appendLine("H2 (m)        : ${number(result.upperScaleMeters)}")
        result.statistics.forEach { statistic ->
            val paddedLabel = when (statistic.denominator) {
                3 -> "H1/3 (m)     "
                10 -> "H1/10 (m)    "
                50 -> "H1/50 (m)    "
                100 -> "H1/100 (m)   "
                250 -> "H1/250 (m)   "
                else -> "H1/1000 (m)  "
            }
            appendLine("$paddedLabel : ${number(statistic.heightMeters)}")
        }
        appendLine()
        appendLine("=======================")
        appendLine("   DIAGNOSTIC RATIOS")
        appendLine("=======================")
        result.diagnosticRatios.forEach { ratio ->
            val paddedLabel = when (ratio.numeratorDenominator) {
                10 -> "(H1/10)/(H1/3)  "
                50 -> "(H1/50)/(H1/3)  "
                100 -> "(H1/100)/(H1/3) "
                250 -> "(H1/250)/(H1/3) "
                else -> "(H1/1000)/(H1/3)"
            }
            appendLine("$paddedLabel : ${number(ratio.value)}")
        }
        appendLine()
        appendLine("End of Report")
    }

    private fun number(value: Double): String = String.format(Locale.US, "%.4f", value)
}
