package com.example.weibull.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.weibull.R
import com.example.weibull.ui.theme.FormulaTextStyle

/**
 * In-app engineering reference for the exact equations implemented by
 * WeibullCalculator and the original shallow-water-waves_gui.cpp model.
 */
@Composable
fun WeibullTheoryScreen(onBack: () -> Unit) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
    ) { scaffoldPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(scaffoldPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .testTag("theory_screen"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                TheoryHeader(onBack = onBack)
            }
            items(
                count = theorySections.size,
                key = { theorySections[it].number },
            ) { index ->
                TheorySectionCard(theorySections[index])
            }
            item {
                TextButton(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 52.dp),
                ) {
                    Text(stringResource(R.string.theory_back))
                }
            }
        }
    }
}

@Composable
private fun TheoryHeader(onBack: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        tonalElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton(
                onClick = onBack,
                modifier = Modifier
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("theory_back"),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Text("← " + stringResource(R.string.theory_back))
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .background(
                            MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f),
                            CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "W",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Text(
                        text = stringResource(R.string.theory_title),
                        modifier = Modifier.semantics { heading() },
                        style = MaterialTheme.typography.headlineMedium,
                    )
                    Text(
                        text = stringResource(R.string.theory_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f),
                    )
                }
            }
        }
    }
}

@Composable
private fun TheorySectionCard(section: TheorySection) {
    val cardModifier = if (section.testTag == null) {
        Modifier.fillMaxWidth()
    } else {
        Modifier
            .fillMaxWidth()
            .testTag(section.testTag)
    }
    Card(
        modifier = cardModifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    shape = CircleShape,
                ) {
                    Box(
                        modifier = Modifier.size(36.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            section.number,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
                Text(
                    text = section.title,
                    modifier = Modifier
                        .weight(1f)
                        .semantics { heading() },
                    style = MaterialTheme.typography.titleLarge,
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            section.blocks.forEach { block ->
                when (block) {
                    is TheoryParagraph -> Text(
                        text = block.text,
                        style = MaterialTheme.typography.bodyLarge,
                    )

                    is TheorySubheading -> Text(
                        text = block.text,
                        modifier = Modifier.semantics { heading() },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )

                    is TheoryEquation -> FormulaBlock(block)
                    is TheoryBullets -> BulletList(block.items)
                    is TheoryCallout -> TheoryCalloutBlock(block.text)
                }
            }
        }
    }
}

@Composable
private fun FormulaBlock(equation: TheoryEquation) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
    ) {
        SelectionContainer {
            Text(
                text = equation.text,
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(14.dp)
                    .semantics {
                        contentDescription = equation.spokenDescription
                    },
                style = FormulaTextStyle,
                color = MaterialTheme.colorScheme.onSurface,
                softWrap = false,
            )
        }
    }
}

@Composable
private fun BulletList(items: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = item,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}

@Composable
private fun TheoryCalloutBlock(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shape = RoundedCornerShape(14.dp),
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(14.dp),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

private data class TheorySection(
    val number: String,
    val title: String,
    val blocks: List<TheoryBlock>,
    val testTag: String? = null,
)

private sealed interface TheoryBlock

private data class TheoryParagraph(val text: String) : TheoryBlock

private data class TheorySubheading(val text: String) : TheoryBlock

private data class TheoryEquation(
    val text: String,
    val spokenDescription: String,
) : TheoryBlock

private data class TheoryBullets(val items: List<String>) : TheoryBlock

private data class TheoryCallout(val text: String) : TheoryBlock

private val theorySections = listOf(
    TheorySection(
        number = "1",
        title = "What this calculator predicts",
        blocks = listOf(
            TheoryParagraph(
                "The calculator estimates the local, short-term distribution of individual " +
                    "zero-crossing wave heights on a shallow, gently sloping foreshore. It uses " +
                    "the Battjes–Groenendijk Composite Weibull distribution and switches to exact " +
                    "Rayleigh mean-high-wave statistics when the normalized transition height is " +
                    "strictly greater than 2.75.",
            ),
            TheoryParagraph(
                "A Rayleigh sea is a useful linear, Gaussian, narrow-band reference. In shallow " +
                    "water, depth-induced breaking suppresses the largest waves more strongly than " +
                    "the smaller waves. The model therefore joins a lower, Rayleigh-shaped branch " +
                    "to a faster-decaying upper branch at a transition height Htr.",
            ),
            TheoryBullets(
                listOf(
                    "Lower population: smaller waves that are substantially non-breaking.",
                    "Upper population: breaking or recently broken waves in the distribution tail.",
                    "Htr: empirical height at which the two mathematical populations meet.",
                ),
            ),
            TheoryCallout(
                "This is a point-statistics model. It does not propagate a spectrum along a profile, " +
                    "simulate a time series, or calculate setup and dissipation between locations.",
            ),
        ),
    ),
    TheorySection(
        number = "2",
        title = "Inputs, notation, and normalization",
        blocks = listOf(
            TheoryParagraph(
                "All three inputs must be positive, finite, local values referring to the same " +
                    "position and water level.",
            ),
            TheoryBullets(
                listOf(
                    "Hm0: local spectral significant wave height in metres; Hm0 = 4√m0.",
                    "d: local still-water depth in metres.",
                    "M: denominator of the foreshore slope 1:M. For 1:100, enter 100.",
                    "H: an individual zero-crossing wave height.",
                    "Hrms: root-mean-square individual wave height used for normalization.",
                    "H1 and H2: lower- and upper-branch Weibull scale parameters.",
                    "k1 and k2: lower- and upper-branch shape exponents.",
                    "A tilde means division by Hrms; for example, H̃ = H/Hrms.",
                ),
            ),
            TheoryEquation(
                text = "tan(α) = 1 / M",
                spokenDescription = "The tangent of alpha equals one divided by the slope denominator M.",
            ),
            TheoryCallout(
                "M is not an angle and not the decimal gradient. H1 and H2 are mathematical " +
                    "distribution scales; they are not physical breaker heights.",
            ),
        ),
    ),
    TheorySection(
        number = "3",
        title = "Local physical quantities",
        blocks = listOf(
            TheoryParagraph(
                "The supplied Hm0 is first converted to free-surface variance. The empirical " +
                    "Battjes–Groenendijk relation then supplies Hrms, while the local depth and " +
                    "slope determine the transition height.",
            ),
            TheoryEquation(
                text = """
                    m0 = (Hm0 / 4)^2
                    √m0 = Hm0 / 4

                    Hrms = (2.69 + 3.24 × √m0 / d) × √m0
                """.trimIndent(),
                spokenDescription = "M zero equals H M zero divided by four, squared. H R M S equals two point six nine plus three point two four times square root of M zero divided by depth, all multiplied by square root of M zero.",
            ),
            TheoryEquation(
                text = """
                    Htr = (0.35 + 5.8 × tan(α)) × d
                        = (0.35 + 5.8 / M) × d

                    H̃tr = Htr / Hrms
                """.trimIndent(),
                spokenDescription = "Transition height equals zero point three five plus five point eight times tangent alpha, multiplied by depth. Normalized transition height equals transition height divided by H R M S.",
            ),
            TheorySubheading("Saturation form"),
            TheoryParagraph(
                "Define the local saturation parameter μ. This form makes the control variables " +
                    "especially clear: relative wave height Hm0/d and slope denominator M.",
            ),
            TheoryEquation(
                text = """
                    μ = √m0 / d = Hm0 / (4d)

                    H̃tr = (0.35 + 5.8/M) / [(2.69 + 3.24μ)μ]
                """.trimIndent(),
                spokenDescription = "Mu equals square root of M zero divided by depth, also H M zero divided by four depth. Normalized transition height is the slope term divided by the H R M S saturation term.",
            ),
            TheoryParagraph(
                "A smaller H̃tr places more of the wave-height population in the breaking-controlled " +
                    "upper branch. A larger H̃tr approaches the Rayleigh limit.",
            ),
        ),
    ),
    TheorySection(
        number = "4",
        title = "Composite Weibull distribution",
        blocks = listOf(
            TheoryParagraph(
                "The calculator works with the exceedance probability Q(H), also called the survival " +
                    "function: the probability that an individual wave height is greater than H.",
            ),
            TheoryEquation(
                text = """
                    H̃ = H / Hrms       H̃1 = H1 / Hrms
                    H̃2 = H2 / Hrms    H̃tr = Htr / Hrms

                    Q(H) = P(wave height > H)

                    H ≤ Htr:  Q(H) = exp[-(H/H1)^k1]
                    H > Htr:  Q(H) = exp[-(H/H2)^k2]

                    k1 = 2.0            k2 = 3.6
                """.trimIndent(),
                spokenDescription = "The Composite Weibull exceedance probability uses a lower branch exponential with shape two up to the transition, and an upper branch exponential with shape three point six above the transition.",
            ),
            TheoryParagraph(
                "Because k1 equals 2, the lower branch has Rayleigh form. The larger value k2 = 3.6 " +
                    "makes the breaking-controlled upper tail decay more quickly.",
            ),
        ),
    ),
    TheorySection(
        number = "5",
        title = "Continuity and the Hrms constraint",
        blocks = listOf(
            TheoryParagraph(
                "For a given H̃tr, the unknown normalized scales H̃1 and H̃2 are fixed by two equations. " +
                    "The first joins the two exceedance curves continuously. The second makes the " +
                    "normalized second moment exactly one, which is required because heights are " +
                    "normalized by Hrms.",
            ),
            TheoryEquation(
                text = """
                    x1 = (H̃tr / H̃1)^k1
                    x2 = (H̃tr / H̃2)^k2

                    Continuity:  x1 = x2
                """.trimIndent(),
                spokenDescription = "X one and X two are the powered normalized transition ratios. Continuity requires X one to equal X two.",
            ),
            TheoryEquation(
                text = """
                    E[H̃^r] =
                      H̃1^r × γ(1 + r/k1, x1)
                      + H̃2^r × Γ(1 + r/k2, x2)

                    E[H̃^2] =
                      H̃1^2 × γ(1 + 2/k1, x1)
                      + H̃2^2 × Γ(1 + 2/k2, x2)
                      = 1
                """.trimIndent(),
                spokenDescription = "The normalized moment is the sum of lower and upper incomplete gamma contributions. For the second moment, that sum must equal one.",
            ),
            TheoryEquation(
                text = """
                    P(H > Htr) = exp(-xtr)
                    xtr = x1 = x2
                    Ntr = exp(xtr)
                """.trimIndent(),
                spokenDescription = "Transition exceedance probability is exponential minus X transition, and the nominal transition recurrence count is exponential X transition.",
            ),
        ),
    ),
    TheorySection(
        number = "6",
        title = "Incomplete gamma functions",
        blocks = listOf(
            TheoryParagraph(
                "The moment integrals use unnormalized incomplete gamma functions. Regularized library " +
                    "functions P(a,x) and Q(a,x) are not direct replacements unless they are multiplied " +
                    "by the complete gamma Γ(a).",
            ),
            TheoryEquation(
                text = """
                    Γ(a)   = ∫[0,∞] t^(a-1) exp(-t) dt
                    γ(a,x) = ∫[0,x] t^(a-1) exp(-t) dt
                    Γ(a,x) = ∫[x,∞] t^(a-1) exp(-t) dt

                    Γ(a,x) = Γ(a) - γ(a,x)
                """.trimIndent(),
                spokenDescription = "Complete gamma integrates from zero to infinity. Lower incomplete gamma integrates from zero to X. Upper incomplete gamma integrates from X to infinity, and equals complete gamma minus lower incomplete gamma.",
            ),
            TheoryParagraph(
                "The implementation evaluates the lower function by a convergent series when " +
                    "x < a + 1 and by a continued fraction otherwise. It obtains the upper function " +
                    "as Γ(a) - γ(a,x). The gamma iteration tolerance is 10^-16 and its maximum is " +
                    "500 iterations.",
            ),
        ),
    ),
    TheorySection(
        number = "7",
        title = "Newton–Raphson scale solution",
        blocks = listOf(
            TheoryParagraph(
                "The app solves continuity and the second-moment condition simultaneously for " +
                    "H̃1 and H̃2. Both residuals must converge; satisfying only one is not a valid " +
                    "Composite Weibull distribution.",
            ),
            TheoryEquation(
                text = """
                    F1 =
                      √[H̃1^2 γ(1 + 2/k1, x1)
                        + H̃2^2 Γ(1 + 2/k2, x2)] - 1

                    F2 = x1 - x2

                    Required solution:  F1 = 0 and F2 = 0
                """.trimIndent(),
                spokenDescription = "F one is the square root second-moment residual minus one. F two is the continuity residual X one minus X two. Both must equal zero.",
            ),
            TheoryEquation(
                text = """
                    J Δx = -F
                    x(next) = x(current) + Δx

                    ∂Fi/∂xj ≈
                      [Fi(xj + δ) - Fi(xj - δ)] / (2δ)
                """.trimIndent(),
                spokenDescription = "Each Newton step solves Jacobian times the update equals negative residual. The Jacobian uses centred finite differences.",
            ),
            TheoryBullets(
                listOf(
                    "Residual tolerance: 1 × 10^-12 for each equation.",
                    "Centred Jacobian increment δ: 1 × 10^-8.",
                    "Maximum Newton iterations: 100.",
                    "The 2 by 2 linear update is solved explicitly; a failed convergence is reported to the user.",
                ),
            ),
            TheorySubheading("Empirical starting estimates"),
            TheoryEquation(
                text = """
                    Let x = H̃tr

                    H̃1(start) =
                      tanh(6.739139344110821x - 0.01265095590917251)
                        ^(-0.6551633251836707)
                      /
                      tanh[sinh(0.6947756601426412x
                        + 0.7908718490781483)]
                        ^(5.484052848550241)

                    H̃2(start) =
                      1.059259665431797
                      + (0.2059286860468916x)
                        / [1 + 3.865701948059343
                          × x^(-3.479682433107255)]
                """.trimIndent(),
                spokenDescription = "The solver uses empirical functions of normalized transition height as starting estimates for the two scale parameters before Newton iteration.",
            ),
            TheoryCallout(
                "These expressions only initialize the numerical iteration. They are not extra " +
                    "physical laws and they do not replace the converged two-equation solution.",
            ),
        ),
    ),
    TheorySection(
        number = "8",
        title = "Two different high-wave statistics",
        blocks = listOf(
            TheoryParagraph(
                "An exceedance threshold and a mean-high-wave height answer different questions. " +
                    "The results table reports the second quantity.",
            ),
            TheoryEquation(
                text = """
                    HN:
                      P(H > HN) = 1/N

                    H1/N:
                      E[H | H > HN]
                      = N × ∫[HN,∞] H f(H) dH
                """.trimIndent(),
                spokenDescription = "H N is the threshold exceeded with probability one over N. H one over N is the conditional mean height of waves above that threshold.",
            ),
            TheoryBullets(
                listOf(
                    "HN is exceeded, on average, once in N individual waves.",
                    "H1/N is the mean height of the highest one-over-N fraction of waves.",
                    "H1/1000 is the mean of the highest 0.1 percent, not a deterministic maximum.",
                ),
            ),
        ),
    ),
    TheorySection(
        number = "9",
        title = "Threshold and mean-high-wave formulas",
        blocks = listOf(
            TheoryParagraph(
                "The lower-branch candidate is tested first. The code uses a 10^-12 transition " +
                    "margin in this comparison, matching the solver tolerance.",
            ),
            TheoryEquation(
                text = """
                    Lower candidate:
                      H̃N,1 = H̃1 × (ln N)^(1/k1)

                    If H̃N,1 < H̃tr:
                      H̃N = H̃1 × (ln N)^(1/k1)

                    Otherwise:
                      H̃N = H̃2 × (ln N)^(1/k2)
                """.trimIndent(),
                spokenDescription = "The candidate exceedance height is computed on the lower branch. If it is below transition, the lower formula is used; otherwise the upper formula is used.",
            ),
            TheoryParagraph(
                "When H̃N lies below H̃tr, the conditional-mean integral crosses the rest of the " +
                    "lower branch and all of the upper branch.",
            ),
            TheoryEquation(
                text = """
                    For H̃N < H̃tr:

                    H̃1/N =
                      N H̃1 [
                        Γ(1 + 1/k1, ln N)
                        - Γ(1 + 1/k1, x1)
                      ]
                      + N H̃2 Γ(1 + 1/k2, x2)
                """.trimIndent(),
                spokenDescription = "Below transition, normalized mean-high-wave height is the sum of a lower-branch upper-gamma interval and the entire upper-branch gamma tail.",
            ),
            TheoryEquation(
                text = """
                    For H̃N ≥ H̃tr:

                    H̃1/N =
                      N H̃2 Γ(1 + 1/k2, ln N)

                    Uncapped B&G metres:
                      H1/N = H̃1/N × Hrms
                """.trimIndent(),
                spokenDescription = "At or above transition, the normalized mean-high-wave height uses only the upper branch. The raw dimensional result is normalized height multiplied by H R M S.",
            ),
            TheoryParagraph(
                "The calculator evaluates N = 3, 10, 50, 100, 250, and 1000.",
            ),
        ),
    ),
    TheorySection(
        number = "10",
        title = "Rayleigh limit and dimensional safeguards",
        blocks = listOf(
            TheoryParagraph(
                "The normalized Composite Weibull shape approaches Rayleigh as H̃tr increases. " +
                    "However, the empirical B&G Hrms relation tends toward 2.69√m0, whereas ideal " +
                    "narrow-band Rayleigh theory uses √(8m0). The calculator therefore uses an exact " +
                    "Rayleigh branch and dimensional caps.",
            ),
            TheoryEquation(
                text = """
                    Ideal-Rayleigh RMS height:
                      Hrms,R = √(8m0) = Hm0/√2

                    Rayleigh CDF:
                      F(H) = 1 - exp[-(H/Hrms,R)^2]

                    HN = Hrms,R × √(ln N)
                    H1/N = N Hrms,R Γ(3/2, ln N)
                """.trimIndent(),
                spokenDescription = "Ideal Rayleigh H R M S equals square root of eight M zero, or H M zero divided by square root of two. The Rayleigh cumulative distribution, threshold, and conditional mean use that ideal Rayleigh scale.",
            ),
            TheoryEquation(
                text = """
                    Branch rule:
                      if H̃tr > 2.75  → direct Rayleigh
                      if H̃tr ≤ 2.75 → Composite Weibull

                    The comparison is strict:
                      H̃tr = 2.75 remains Composite Weibull.
                """.trimIndent(),
                spokenDescription = "Direct Rayleigh is used only when normalized transition height is strictly greater than two point seven five. Equality remains Composite Weibull.",
            ),
            TheorySubheading("Exact Rayleigh mean-high-wave ratios"),
            TheoryEquation(
                text = """
                    Statistic   CN = H1/N / Hm0
                    H1/3       1.001075736951740
                    H1/10      1.272734273369137
                    H1/50      1.560113379974762
                    H1/100     1.668233372358517
                    H1/250     1.801017222497626
                    H1/1000    1.984835590575388
                """.trimIndent(),
                spokenDescription = "The exact Rayleigh ratios to H M zero are listed for the six mean-high-wave fractions from one third through one thousandth.",
            ),
            TheoryEquation(
                text = """
                    In the B&G branch, for each N:

                    Final H1/N =
                      min(raw B&G H1/N, CN × Hm0)
                """.trimIndent(),
                spokenDescription = "Each final Composite Weibull dimensional result is the smaller of the raw result and its Rayleigh constant times H M zero.",
            ),
            TheoryCallout(
                "Exact implementation detail: in the B&G branch, the dimensionless table retains " +
                    "the raw Composite Weibull ratios. The metre table is capped independently. " +
                    "Diagnostic ratios use the final capped metre values. This mirrors the supplied " +
                    "C++ calculation. In the direct Rayleigh branch, metre heights are CN × Hm0; " +
                    "the dimensionless rows divide those heights by the separately reported empirical " +
                    "B&G Hrms, not by Hrms,R. H1 and H2 are not solved there, so displayed zero scale " +
                    "values mean “not applicable,” not physical zero heights.",
            ),
        ),
    ),
    TheorySection(
        number = "11",
        title = "Outputs and diagnostic checks",
        blocks = listOf(
            TheoryBullets(
                listOf(
                    "Distribution: B&G means the Composite Weibull equations were solved; Rayleigh means H̃tr > 2.75.",
                    "Calculated parameters: m0, tan(α), and the two scale values H1 and H2.",
                    "Dimensionless heights: ratios to the reported empirical B&G Hrms; these are raw distribution ratios in the B&G branch and CN × Hm0/Hrms in the direct Rayleigh branch.",
                    "Dimensional heights: final metre values, including individual Rayleigh caps in the B&G branch.",
                    "Engineering report: the same inputs, parameters, statistics, and diagnostics in copyable text.",
                ),
            ),
            TheoryEquation(
                text = """
                    Tail-shape diagnostics:

                    H1/10   / H1/3
                    H1/50   / H1/3
                    H1/100  / H1/3
                    H1/250  / H1/3
                    H1/1000 / H1/3
                """.trimIndent(),
                spokenDescription = "The diagnostic ratios divide each final higher-tail dimensional mean by the final mean of the highest one third.",
            ),
            TheorySubheading("Useful numerical checks"),
            TheoryBullets(
                listOf(
                    "The continuity residual and second-moment residual should both be close to zero.",
                    "Final metre values should increase from H1/3 through H1/1000.",
                    "Every B&G metre result must be no greater than its CN × Hm0 Rayleigh cap.",
                    "Before any cap, raw H1/N equals raw H̃1/N multiplied by Hrms.",
                ),
            ),
        ),
    ),
    TheorySection(
        number = "12",
        title = "Calculation sequence used by the app",
        blocks = listOf(
            TheoryBullets(
                listOf(
                    "1. Parse Hm0, d, and M and reject non-finite or non-positive values.",
                    "2. Calculate m0 and √m0 from Hm0.",
                    "3. Calculate the empirical local Hrms.",
                    "4. Convert slope denominator M to tan(α).",
                    "5. Calculate Htr and H̃tr.",
                    "6. If H̃tr > 2.75, use the six exact Rayleigh ratios.",
                    "7. Otherwise solve the two Composite Weibull scale equations.",
                    "8. For every N, decide which branch contains HN.",
                    "9. Integrate the appropriate incomplete-gamma expression for H̃1/N.",
                    "10. Convert each raw normalized B&G statistic to metres.",
                    "11. Cap every B&G metre value independently at CN × Hm0.",
                    "12. Form diagnostics from the final dimensional values.",
                    "13. Populate the on-screen parameter, normalized, dimensional, and diagnostic tables.",
                    "14. Generate the copyable engineering report from the same result object.",
                ),
            ),
        ),
    ),
    TheorySection(
        number = "13",
        title = "Applicability and limitations",
        testTag = "theory_limitations",
        blocks = listOf(
            TheorySubheading("Recommended calibration domain"),
            TheoryBullets(
                listOf(
                    "Plane, shallow foreshores with slopes approximately from 1:20 to 1:250.",
                    "0 < √m0/d < 0.15, approximately equivalent to 0 < Hm0/d < 0.6.",
                    "Straight, broadly parallel contours and gradually varying bathymetry.",
                    "Enough propagation distance for the local wave population to adapt to the local depth.",
                ),
            ),
            TheoryParagraph(
                "Use caution for slopes steeper than 1:20. A constant-depth flat bottom is not " +
                    "equivalent to a 1:250 foreshore; substituting M = 250 for a flat bed can " +
                    "underestimate the large-wave statistics.",
            ),
            TheorySubheading("Processes not explicitly represented"),
            TheoryBullets(
                listOf(
                    "Wave period, full spectral shape, and directional spreading.",
                    "Currents, reflection, local wind growth, and diffraction.",
                    "Bars, troughs, reef edges, channels, or abrupt bathymetric changes.",
                    "Infragravity-wave separation, wave grouping, and nonstationarity.",
                    "Uncertainty propagation or storm-duration maximum-wave statistics.",
                ),
            ),
            TheoryCallout(
                "Outside the calibration domain, use engineering judgement, sensitivity tests, " +
                    "measurements, and an independent model where consequences justify them. The " +
                    "calculator is a statistics tool, not a substitute for site-specific design review.",
            ),
        ),
    ),
    TheorySection(
        number = "14",
        title = "Interpretation checklist and basis",
        blocks = listOf(
            TheoryBullets(
                listOf(
                    "Hm0, H1/3, HN, and H1/N are different quantities.",
                    "H1 and H2 are distribution scales, not breaker heights.",
                    "A recurrence denominator N counts individual waves, not seconds or sea states.",
                    "H1/1000 is a conditional mean of the highest 0.1 percent, not a storm maximum.",
                    "Use local Hm0 and d at the same water level and location.",
                    "Read B&G normalized rows as raw distribution values and metre rows as final safeguarded values.",
                ),
            ),
            TheoryParagraph(
                "Scientific basis: the main reference is Battjes–Groenendijk shallow-water Composite Weibull model " +
                    "documented in the literature. The equations, constants, numerical tolerances, " +
                    "strict branch boundary, and output behavior shown here are aligned with " +
                    "the cited literature.",
            ),
            TheorySubheading("Core references"),
            TheoryBullets(
                listOf(
                    "Battjes, J. A., and Groenendijk, H. W. (2000). Wave height distributions on shallow foreshores. Coastal Engineering 40, 161–182.",
                    "Caires, S., and Van Gent, M. R. A. (2012). Wave height distribution in constant and finite depths. 33rd International Conference on Coastal Engineering.",
                    "Groenendijk, H. W. (1998). Shallow foreshore wave height statistics. MSc thesis, Delft University of Technology.",
                    "Groenendijk, H. W., and Van Gent, M. R. A. (1998). Shallow foreshore wave height statistics: a predictive model for wave-height exceedance. WL | Delft Hydraulics Report H3351.",
                ),
            ),
        ),
    ),
)
