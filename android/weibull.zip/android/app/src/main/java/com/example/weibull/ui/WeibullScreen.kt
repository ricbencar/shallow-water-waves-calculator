package com.example.weibull.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.weibull.R
import com.example.weibull.solver.DistributionType
import com.example.weibull.solver.WaveAnalysisResult
import com.example.weibull.ui.theme.NumericTextStyle
import com.example.weibull.ui.theme.ReportTextStyle
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun WeibullScreen(
    state: WeibullUiState,
    onIntent: (WeibullIntent) -> Unit,
    onShowTheory: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val copiedMessage = stringResource(R.string.report_copied)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { scaffoldPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(scaffoldPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { AppHeader() }
            item { TheoryLinkSeparator(onClick = onShowTheory) }
            item { InputCard(state = state, onIntent = onIntent) }
            state.result?.let { result ->
                item { ResultSummary(result) }
                item { DimensionalResults(result) }
                item { ParameterResults(result) }
                item { DimensionlessResults(result) }
                item { DiagnosticResults(result) }
                item {
                    ReportCard(
                        report = state.report,
                        onCopy = {
                            val clipboard = context.getSystemService(ClipboardManager::class.java)
                            clipboard.setPrimaryClip(
                                ClipData.newPlainText("weibull engineering report", state.report),
                            )
                            coroutineScope.launch { snackbarHostState.showSnackbar(copiedMessage) }
                        },
                        onShare = { shareReport(context, state.report) },
                    )
                }
            }
            item { ModelNote() }
        }
    }

    if (state.calculationFailed) {
        AlertDialog(
            onDismissRequest = { onIntent(WeibullIntent.DismissError) },
            confirmButton = {
                TextButton(onClick = { onIntent(WeibullIntent.DismissError) }) {
                    Text(stringResource(R.string.dismiss))
                }
            },
            title = { Text(stringResource(R.string.calculation_error)) },
            text = {
                Text("Try another set of positive local wave conditions.")
            },
        )
    }
}

@Composable
private fun TheoryLinkSeparator(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outlineVariant,
        )
        TextButton(
            onClick = onClick,
            modifier = Modifier
                .height(48.dp)
                .testTag("weibull_theory_link"),
        ) {
            Text(
                text = stringResource(R.string.weibull_theory),
                style = MaterialTheme.typography.labelLarge,
                textDecoration = TextDecoration.Underline,
            )
        }
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outlineVariant,
        )
    }
}

@Composable
private fun AppHeader() {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        tonalElevation = 4.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "W",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    text = stringResource(R.string.screen_title),
                    style = MaterialTheme.typography.headlineMedium,
                )
                Text(
                    text = stringResource(R.string.screen_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f),
                )
            }
        }
    }
}

@Composable
private fun InputCard(
    state: WeibullUiState,
    onIntent: (WeibullIntent) -> Unit,
) {
    val focusManager = LocalFocusManager.current
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(stringResource(R.string.inputs_title), style = MaterialTheme.typography.titleLarge)
            Text(
                stringResource(R.string.inputs_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            DecimalField(
                value = state.hm0,
                onValueChange = { onIntent(WeibullIntent.Hm0Changed(it)) },
                label = stringResource(R.string.hm0_label),
                hasError = state.hm0HasError,
                imeAction = ImeAction.Next,
            )
            DecimalField(
                value = state.waterDepth,
                onValueChange = { onIntent(WeibullIntent.WaterDepthChanged(it)) },
                label = stringResource(R.string.depth_label),
                hasError = state.waterDepthHasError,
                imeAction = ImeAction.Next,
            )
            DecimalField(
                value = state.slopeDenominator,
                onValueChange = { onIntent(WeibullIntent.SlopeChanged(it)) },
                label = stringResource(R.string.slope_label),
                hasError = state.slopeHasError,
                imeAction = ImeAction.Done,
                onDone = {
                    focusManager.clearFocus()
                    onIntent(WeibullIntent.Calculate)
                },
            )
            Button(
                onClick = {
                    focusManager.clearFocus()
                    onIntent(WeibullIntent.Calculate)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text(stringResource(R.string.calculate))
            }
        }
    }
}

@Composable
private fun DecimalField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    hasError: Boolean,
    imeAction: ImeAction,
    onDone: () -> Unit = {},
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        isError = hasError,
        supportingText = if (hasError) {
            { Text(stringResource(R.string.positive_value_error)) }
        } else {
            null
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Decimal,
            imeAction = imeAction,
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        shape = RoundedCornerShape(14.dp),
    )
}

@Composable
private fun ResultSummary(result: WaveAnalysisResult) {
    val isRayleigh = result.distribution == DistributionType.RAYLEIGH
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
        ),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        stringResource(R.string.results_title),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        if (isRayleigh) "Deep-water limit" else "Composite Weibull solution",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f),
                    )
                }
                Surface(
                    color = if (isRayleigh) {
                        MaterialTheme.colorScheme.tertiaryContainer
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer
                    },
                    shape = RoundedCornerShape(50),
                ) {
                    Text(
                        text = result.distribution.displayName,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.18f))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                SummaryMetric("Hrms", "${format(result.hrms)} m", Modifier.weight(1f))
                SummaryMetric("Htr", "${format(result.transitionHeightMeters)} m", Modifier.weight(1f))
                SummaryMetric("Htr/Hrms", format(result.normalizedTransitionHeight), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SummaryMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f),
            textAlign = TextAlign.Center,
        )
        Text(
            value,
            style = NumericTextStyle,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun DimensionalResults(result: WaveAnalysisResult) {
    ResultTable(
        title = stringResource(R.string.dimensional_title),
        columns = "Statistic" to "Height (m)",
        rows = result.statistics.map { it.label to format(it.heightMeters) },
    )
}

@Composable
private fun ParameterResults(result: WaveAnalysisResult) {
    val rows = buildList {
        add("m0" to "${format(result.freeSurfaceVariance)} m²")
        add("tan α" to format(result.tanAlpha))
        add("H1" to "${format(result.lowerScaleMeters)} m")
        add("H2" to "${format(result.upperScaleMeters)} m")
    }
    ResultTable(
        title = stringResource(R.string.parameters_title),
        columns = "Parameter" to "Value",
        rows = rows,
    )
}

@Composable
private fun DimensionlessResults(result: WaveAnalysisResult) {
    val rows = buildList {
        add("H1/Hrms" to format(result.lowerScaleToHrms))
        add("H2/Hrms" to format(result.upperScaleToHrms))
        result.statistics.forEach { add("${it.label}/Hrms" to format(it.ratioToHrms)) }
    }
    ResultTable(
        title = stringResource(R.string.dimensionless_title),
        columns = "Statistic" to "Value",
        rows = rows,
    )
}

@Composable
private fun DiagnosticResults(result: WaveAnalysisResult) {
    ResultTable(
        title = stringResource(R.string.diagnostics_title),
        columns = "Ratio" to "Value",
        rows = result.diagnosticRatios.map { it.label to format(it.value) },
    )
}

@Composable
private fun ResultTable(
    title: String,
    columns: Pair<String, String>,
    rows: List<Pair<String, String>>,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(modifier = Modifier.padding(vertical = 18.dp)) {
            Text(
                title,
                modifier = Modifier.padding(horizontal = 20.dp),
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 20.dp, vertical = 9.dp),
            ) {
                Text(columns.first, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                Text(columns.second, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.End)
            }
            rows.forEachIndexed { index, row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (index % 2 == 0) Color.Transparent
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.36f),
                        )
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(row.first, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    Text(row.second, style = NumericTextStyle, textAlign = TextAlign.End)
                }
            }
        }
    }
}

@Composable
private fun ReportCard(
    report: String,
    onCopy: () -> Unit,
    onShare: () -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(stringResource(R.string.report_title), style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onCopy, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.copy_action))
                }
                Button(
                    onClick = onShare,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                ) {
                    Text(stringResource(R.string.share_action))
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(14.dp),
                    )
                    .horizontalScroll(rememberScrollState())
                    .padding(14.dp),
            ) {
                Text(report, style = ReportTextStyle, softWrap = false)
            }
        }
    }
}

@Composable
private fun ModelNote() {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(18.dp),
    ) {
        Text(
            text = "The B&G branch is used at Htr/Hrms ≤ 2.75. Above that threshold, " +
                "the calculator uses exact Rayleigh statistics. Dimensional B&G results " +
                "are capped at their Rayleigh limits.",
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

private fun shareReport(context: Context, report: String) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.share_subject))
        putExtra(Intent.EXTRA_TEXT, report)
    }
    context.startActivity(
        Intent.createChooser(shareIntent, context.getString(R.string.share_chooser_title)),
    )
}

private fun format(value: Double): String = String.format(Locale.US, "%.4f", value)
