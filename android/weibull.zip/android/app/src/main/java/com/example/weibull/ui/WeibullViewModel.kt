package com.example.weibull.ui

import androidx.lifecycle.ViewModel
import com.example.weibull.report.WeibullReportFormatter
import com.example.weibull.solver.WaveAnalysisResult
import com.example.weibull.solver.WaveInput
import com.example.weibull.solver.WeibullCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class WeibullUiState(
    val hm0: String = "2.5",
    val waterDepth: String = "5.0",
    val slopeDenominator: String = "100",
    val hm0HasError: Boolean = false,
    val waterDepthHasError: Boolean = false,
    val slopeHasError: Boolean = false,
    val result: WaveAnalysisResult? = null,
    val report: String = "",
    val calculationFailed: Boolean = false,
)

sealed interface WeibullIntent {
    data class Hm0Changed(val value: String) : WeibullIntent
    data class WaterDepthChanged(val value: String) : WeibullIntent
    data class SlopeChanged(val value: String) : WeibullIntent
    data object Calculate : WeibullIntent
    data object DismissError : WeibullIntent
}

class WeibullViewModel : ViewModel() {
    private val mutableState = MutableStateFlow(WeibullUiState())
    val state: StateFlow<WeibullUiState> = mutableState.asStateFlow()

    fun onIntent(intent: WeibullIntent) {
        when (intent) {
            is WeibullIntent.Hm0Changed -> mutableState.update {
                it.copy(
                    hm0 = intent.value,
                    hm0HasError = false,
                    result = null,
                    report = "",
                    calculationFailed = false,
                )
            }
            is WeibullIntent.WaterDepthChanged -> mutableState.update {
                it.copy(
                    waterDepth = intent.value,
                    waterDepthHasError = false,
                    result = null,
                    report = "",
                    calculationFailed = false,
                )
            }
            is WeibullIntent.SlopeChanged -> mutableState.update {
                it.copy(
                    slopeDenominator = intent.value,
                    slopeHasError = false,
                    result = null,
                    report = "",
                    calculationFailed = false,
                )
            }
            WeibullIntent.Calculate -> calculate()
            WeibullIntent.DismissError -> mutableState.update { it.copy(calculationFailed = false) }
        }
    }

    private fun calculate() {
        val current = mutableState.value
        val hm0 = parseDecimal(current.hm0)
        val depth = parseDecimal(current.waterDepth)
        val slope = parseDecimal(current.slopeDenominator)
        val hm0Error = hm0 == null || !hm0.isFinite() || hm0 <= 0.0
        val depthError = depth == null || !depth.isFinite() || depth <= 0.0
        val slopeError = slope == null || !slope.isFinite() || slope <= 0.0

        if (hm0Error || depthError || slopeError) {
            mutableState.update {
                it.copy(
                    hm0HasError = hm0Error,
                    waterDepthHasError = depthError,
                    slopeHasError = slopeError,
                    result = null,
                    report = "",
                    calculationFailed = false,
                )
            }
            return
        }

        runCatching {
            WeibullCalculator.calculate(
                WaveInput(
                    hm0 = requireNotNull(hm0),
                    waterDepth = requireNotNull(depth),
                    slopeDenominator = requireNotNull(slope),
                ),
            )
        }.onSuccess { result ->
            mutableState.update {
                it.copy(
                    result = result,
                    report = WeibullReportFormatter.format(result),
                    calculationFailed = false,
                )
            }
        }.onFailure {
            mutableState.update { it.copy(calculationFailed = true) }
        }
    }
}

internal fun parseDecimal(value: String): Double? {
    val trimmed = value.trim()
    if (trimmed.isEmpty()) return null
    val normalized = if (',' in trimmed && '.' !in trimmed) trimmed.replace(',', '.') else trimmed
    return normalized.toDoubleOrNull()
}
