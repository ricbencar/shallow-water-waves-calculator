package com.example.weibull.ui.theme

import androidx.compose.ui.graphics.Color

val OceanNavy = Color(0xFF073B4C)
val OceanBlue = Color(0xFF0B6E99)
val OceanTeal = Color(0xFF0D9488)
val OceanAmber = Color(0xFFF4A261)
val OceanBackground = Color(0xFFF4F8FA)
val OceanSurface = Color(0xFFFFFFFF)
val OceanText = Color(0xFF102A36)
val OceanMutedText = Color(0xFF526873)
val OceanOutline = Color(0xFF71858E)
val OceanOutlineVariant = Color(0xFFC8D5DA)
val OceanPrimaryContainer = Color(0xFFD0EAF5)
val OceanSecondaryContainer = Color(0xFFD5F2EE)
val OceanSurfaceVariant = Color(0xFFE5EFF2)

val OceanDarkBackground = Color(0xFF06191F)
val OceanDarkSurface = Color(0xFF0B252E)
val OceanDarkSurfaceVariant = Color(0xFF173740)
val OceanDarkPrimary = Color(0xFF89D0EF)
val OceanDarkSecondary = Color(0xFF73D8CD)
val OceanDarkText = Color(0xFFEAF4F7)
val OceanDarkMutedText = Color(0xFFB6C9D0)
val OceanDarkOutline = Color(0xFF8399A2)
val OceanDarkOutlineVariant = Color(0xFF334E58)

val OceanError = Color(0xFFBA1A1A)
val OceanDarkError = Color(0xFFFFB4AB)
