package com.example.weibull

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import com.example.weibull.ui.WeibullScreen
import com.example.weibull.ui.WeibullTheoryScreen
import com.example.weibull.ui.WeibullViewModel
import com.example.weibull.ui.theme.WeibullTheme

class MainActivity : ComponentActivity() {
    private val viewModel: WeibullViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WeibullTheme {
                val state by viewModel.state.collectAsState()
                var showTheory by rememberSaveable { mutableStateOf(false) }
                val screenStateHolder = rememberSaveableStateHolder()

                BackHandler(enabled = showTheory) {
                    showTheory = false
                }

                val screenKey = if (showTheory) "theory" else "calculator"
                screenStateHolder.SaveableStateProvider(screenKey) {
                    if (showTheory) {
                        WeibullTheoryScreen(onBack = { showTheory = false })
                    } else {
                        WeibullScreen(
                            state = state,
                            onIntent = viewModel::onIntent,
                            onShowTheory = { showTheory = true },
                        )
                    }
                }
            }
        }
    }
}
