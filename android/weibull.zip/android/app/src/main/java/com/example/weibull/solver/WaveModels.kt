package com.example.weibull.solver

data class WaveInput(
    val hm0: Double,
    val waterDepth: Double,
    val slopeDenominator: Double,
)

enum class DistributionType(val displayName: String) {
    COMPOSITE_WEIBULL("B&G"),
    RAYLEIGH("Rayleigh"),
}

data class WaveHeightStatistic(
    val denominator: Int,
    val ratioToHrms: Double,
    val heightMeters: Double,
) {
    val label: String = "H1/$denominator"
}

data class DiagnosticRatio(
    val numeratorDenominator: Int,
    val value: Double,
) {
    val label: String = "(H1/$numeratorDenominator)/(H1/3)"
}

data class WaveAnalysisResult(
    val input: WaveInput,
    val distribution: DistributionType,
    val freeSurfaceVariance: Double,
    val hrms: Double,
    val tanAlpha: Double,
    val transitionHeightMeters: Double,
    val normalizedTransitionHeight: Double,
    val lowerScaleToHrms: Double,
    val upperScaleToHrms: Double,
    val lowerScaleMeters: Double,
    val upperScaleMeters: Double,
    val statistics: List<WaveHeightStatistic>,
    val diagnosticRatios: List<DiagnosticRatio>,
)

open class WeibullSolverException(message: String) : RuntimeException(message)

class InvalidWaveInputException(message: String) : WeibullSolverException(message)

class WeibullConvergenceException(message: String) : WeibullSolverException(message)
