package com.example.weibull.solver

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Composite Weibull wave-height calculation ported from shallow-water-waves_gui.cpp.
 * Constants, branch selection, finite-difference Newton iteration, and Rayleigh caps
 * intentionally match the reference implementation.
 */
object WeibullCalculator {
    private const val LOWER_SHAPE = 2.0
    private const val UPPER_SHAPE = 3.6
    private const val SOLVER_EPSILON = 1.0e-12
    private const val JACOBIAN_STEP = 1.0e-8
    private const val GAMMA_EPSILON = 1.0e-16
    private const val MAX_GAMMA_ITERATIONS = 500
    private const val MAX_NEWTON_ITERATIONS = 100
    private const val RAYLEIGH_SWITCH = 2.75

    private val denominators = intArrayOf(3, 10, 50, 100, 250, 1000)
    private val rayleighRatios = doubleArrayOf(
        1.001075736951740,
        1.272734273369137,
        1.560113379974762,
        1.668233372358517,
        1.801017222497626,
        1.984835590575388,
    )

    fun calculate(input: WaveInput): WaveAnalysisResult {
        validate(input)

        val m0 = (input.hm0 / 4.0).pow(2.0)
        val sqrtM0 = sqrt(m0)
        val hrms = (2.69 + 3.24 * sqrtM0 / input.waterDepth) * sqrtM0
        val tanAlpha = 1.0 / input.slopeDenominator
        val transitionHeight = (0.35 + 5.8 * tanAlpha) * input.waterDepth
        val normalizedTransition = if (hrms > 0.0) transitionHeight / hrms else 0.0

        val distribution: DistributionType
        var lowerScaleToHrms = 0.0
        var upperScaleToHrms = 0.0
        var lowerScaleMeters = 0.0
        var upperScaleMeters = 0.0
        val normalizedStatistics: DoubleArray
        val dimensionalStatistics: DoubleArray

        if (normalizedTransition > RAYLEIGH_SWITCH) {
            distribution = DistributionType.RAYLEIGH
            dimensionalStatistics = DoubleArray(denominators.size) { index ->
                rayleighRatios[index] * input.hm0
            }
            normalizedStatistics = DoubleArray(denominators.size) { index ->
                if (hrms > 0.0) dimensionalStatistics[index] / hrms else 0.0
            }
        } else {
            distribution = DistributionType.COMPOSITE_WEIBULL
            val scales = solveScales(normalizedTransition)
            lowerScaleToHrms = scales.first
            upperScaleToHrms = scales.second
            lowerScaleMeters = lowerScaleToHrms * hrms
            upperScaleMeters = upperScaleToHrms * hrms

            normalizedStatistics = DoubleArray(denominators.size) { index ->
                calculateMeanHighestFraction(
                    denominator = denominators[index].toDouble(),
                    lowerScale = lowerScaleToHrms,
                    upperScale = upperScaleToHrms,
                    transitionHeight = normalizedTransition,
                )
            }
            dimensionalStatistics = DoubleArray(denominators.size) { index ->
                min(
                    normalizedStatistics[index] * hrms,
                    rayleighRatios[index] * input.hm0,
                )
            }
        }

        val statistics = denominators.indices.map { index ->
            WaveHeightStatistic(
                denominator = denominators[index],
                ratioToHrms = normalizedStatistics[index],
                heightMeters = dimensionalStatistics[index],
            )
        }
        val referenceHeight = dimensionalStatistics.first()
        val normalizedReferenceHeight = referenceHeight / hrms
        val diagnostics = denominators.indices.drop(1).map { index ->
            DiagnosticRatio(
                numeratorDenominator = denominators[index],
                value = if (referenceHeight > 0.0) {
                    val normalizedHeight = dimensionalStatistics[index] / hrms
                    normalizedHeight / normalizedReferenceHeight
                } else {
                    0.0
                },
            )
        }

        return WaveAnalysisResult(
            input = input,
            distribution = distribution,
            freeSurfaceVariance = m0,
            hrms = hrms,
            tanAlpha = tanAlpha,
            transitionHeightMeters = transitionHeight,
            normalizedTransitionHeight = normalizedTransition,
            lowerScaleToHrms = lowerScaleToHrms,
            upperScaleToHrms = upperScaleToHrms,
            lowerScaleMeters = lowerScaleMeters,
            upperScaleMeters = upperScaleMeters,
            statistics = statistics,
            diagnosticRatios = diagnostics,
        )
    }

    private fun validate(input: WaveInput) {
        if (!input.hm0.isFinite() || input.hm0 <= 0.0) {
            throw InvalidWaveInputException("Hm0 must be finite and greater than zero.")
        }
        if (!input.waterDepth.isFinite() || input.waterDepth <= 0.0) {
            throw InvalidWaveInputException("Water depth must be finite and greater than zero.")
        }
        if (!input.slopeDenominator.isFinite() || input.slopeDenominator <= 0.0) {
            throw InvalidWaveInputException("The slope denominator must be finite and greater than zero.")
        }
    }

    private fun calculateExceedanceHeight(
        denominator: Double,
        lowerScale: Double,
        upperScale: Double,
        transitionHeight: Double,
    ): Double {
        require(denominator > 1.0 && lowerScale > 0.0 && upperScale > 0.0)
        val lowerCandidate = lowerScale * ln(denominator).pow(1.0 / LOWER_SHAPE)
        return if (lowerCandidate < transitionHeight - SOLVER_EPSILON) {
            lowerCandidate
        } else {
            upperScale * ln(denominator).pow(1.0 / UPPER_SHAPE)
        }
    }

    private fun calculateMeanHighestFraction(
        denominator: Double,
        lowerScale: Double,
        upperScale: Double,
        transitionHeight: Double,
    ): Double {
        val exceedanceHeight = calculateExceedanceHeight(
            denominator,
            lowerScale,
            upperScale,
            transitionHeight,
        )
        val logDenominator = ln(denominator)
        val upperMomentShape = 1.0 / UPPER_SHAPE + 1.0

        return if (exceedanceHeight < transitionHeight - SOLVER_EPSILON) {
            val lowerMomentShape = 1.0 / LOWER_SHAPE + 1.0
            val lowerTransition = (transitionHeight / lowerScale).pow(LOWER_SHAPE)
            val upperTransition = (transitionHeight / upperScale).pow(UPPER_SHAPE)
            val lowerContribution = incompleteGammaUpper(lowerMomentShape, logDenominator) -
                incompleteGammaUpper(lowerMomentShape, lowerTransition)
            val upperContribution = incompleteGammaUpper(upperMomentShape, upperTransition)
            denominator * (
                lowerScale * lowerContribution + upperScale * upperContribution
                )
        } else {
            denominator * upperScale * incompleteGammaUpper(upperMomentShape, logDenominator)
        }
    }

    private fun solveScales(normalizedTransition: Double): Pair<Double, Double> {
        var lowerScale = tanh(
            6.739139344110821 * normalizedTransition - 0.01265095590917251,
        ).pow(-0.6551633251836707) / tanh(
            sinh(0.6947756601426412 * normalizedTransition + 0.7908718490781483),
        ).pow(5.484052848550241)
        var upperScale = 1.059259665431797 +
            (0.2059286860468916 * normalizedTransition) /
            (1.0 + 3.865701948059343 * normalizedTransition.pow(-3.479682433107255))

        if (lowerScale <= 0.0) lowerScale = GAMMA_EPSILON
        if (upperScale <= 0.0) upperScale = GAMMA_EPSILON

        repeat(MAX_NEWTON_ITERATIONS) {
            val firstResidual = rmsConstraint(lowerScale, upperScale, normalizedTransition)
            val secondResidual = continuityConstraint(lowerScale, upperScale, normalizedTransition)
            if (abs(firstResidual) < SOLVER_EPSILON && abs(secondResidual) < SOLVER_EPSILON) {
                return lowerScale to upperScale
            }

            val j11 = (
                rmsConstraint(lowerScale + JACOBIAN_STEP, upperScale, normalizedTransition) -
                    rmsConstraint(lowerScale - JACOBIAN_STEP, upperScale, normalizedTransition)
                ) / (2.0 * JACOBIAN_STEP)
            val j12 = (
                rmsConstraint(lowerScale, upperScale + JACOBIAN_STEP, normalizedTransition) -
                    rmsConstraint(lowerScale, upperScale - JACOBIAN_STEP, normalizedTransition)
                ) / (2.0 * JACOBIAN_STEP)
            val j21 = (
                continuityConstraint(lowerScale + JACOBIAN_STEP, upperScale, normalizedTransition) -
                    continuityConstraint(lowerScale - JACOBIAN_STEP, upperScale, normalizedTransition)
                ) / (2.0 * JACOBIAN_STEP)
            val j22 = (
                continuityConstraint(lowerScale, upperScale + JACOBIAN_STEP, normalizedTransition) -
                    continuityConstraint(lowerScale, upperScale - JACOBIAN_STEP, normalizedTransition)
                ) / (2.0 * JACOBIAN_STEP)

            val determinant = j11 * j22 - j12 * j21
            val lowerUpdate: Double
            val upperUpdate: Double
            if (abs(determinant) < 1.0e-20) {
                lowerUpdate = 0.0
                upperUpdate = 0.0
            } else {
                lowerUpdate = ((-firstResidual) * j22 - (-secondResidual) * j12) / determinant
                upperUpdate = (j11 * (-secondResidual) - j21 * (-firstResidual)) / determinant
            }

            lowerScale += lowerUpdate
            upperScale += upperUpdate
            if (lowerScale <= 0.0) lowerScale = GAMMA_EPSILON
            if (upperScale <= 0.0) upperScale = GAMMA_EPSILON
        }

        throw WeibullConvergenceException("Newton-Raphson solver failed to converge.")
    }

    private fun rmsConstraint(
        lowerScale: Double,
        upperScale: Double,
        normalizedTransition: Double,
    ): Double {
        if (lowerScale <= 0.0 || upperScale <= 0.0) return Double.MAX_VALUE
        val lowerArgument = (normalizedTransition / lowerScale).pow(LOWER_SHAPE)
        val upperArgument = (normalizedTransition / upperScale).pow(UPPER_SHAPE)
        val lowerTerm = lowerScale * lowerScale *
            incompleteGammaLower(2.0 / LOWER_SHAPE + 1.0, lowerArgument)
        val upperTerm = upperScale * upperScale *
            incompleteGammaUpper(2.0 / UPPER_SHAPE + 1.0, upperArgument)
        return sqrt(cxxMaxZero(lowerTerm + upperTerm)) - 1.0
    }

    private fun continuityConstraint(
        lowerScale: Double,
        upperScale: Double,
        normalizedTransition: Double,
    ): Double {
        if (lowerScale <= 0.0 || upperScale <= 0.0) return Double.MAX_VALUE
        return (normalizedTransition / lowerScale).pow(LOWER_SHAPE) -
            (normalizedTransition / upperScale).pow(UPPER_SHAPE)
    }

    private fun incompleteGammaLower(shape: Double, x: Double): Double {
        if (shape <= 0.0 || x < 0.0) return Double.NaN
        if (x == 0.0) return 0.0
        val logGamma = logGamma(shape)

        if (x < shape + 1.0) {
            var incrementedShape = shape
            var sum = 1.0 / shape
            var delta = sum
            repeat(MAX_GAMMA_ITERATIONS) {
                incrementedShape += 1.0
                delta *= x / incrementedShape
                sum += delta
                if (abs(delta) < abs(sum) * GAMMA_EPSILON) {
                    return sum * exp(-x + shape * ln(x) - logGamma) * exp(logGamma)
                }
            }
            return Double.NaN
        }

        var b = x + 1.0 - shape
        var c = 1.0 / java.lang.Double.MIN_NORMAL
        var d = 1.0 / b
        var fraction = d
        for (iteration in 1..MAX_GAMMA_ITERATIONS) {
            val an = -1.0 * iteration * (iteration - shape)
            b += 2.0
            d = an * d + b
            if (abs(d) < java.lang.Double.MIN_NORMAL) d = java.lang.Double.MIN_NORMAL
            c = b + an / c
            if (abs(c) < java.lang.Double.MIN_NORMAL) c = java.lang.Double.MIN_NORMAL
            d = 1.0 / d
            val delta = d * c
            fraction *= delta
            if (abs(delta - 1.0) < GAMMA_EPSILON) break
        }
        val normalizedLower = 1.0 - exp(-x + shape * ln(x) - logGamma) * fraction
        return cxxMaxZero(normalizedLower) * exp(logGamma)
    }

    private fun incompleteGammaUpper(shape: Double, x: Double): Double {
        if (shape <= 0.0 || x < 0.0) {
            throw IllegalArgumentException("Invalid arguments for incomplete gamma.")
        }
        return exp(logGamma(shape)) - incompleteGammaLower(shape, x)
    }

    private fun cxxMaxZero(value: Double): Double = if (0.0 < value) value else 0.0

    /** Lanczos approximation at double precision, equivalent to the reference lgamma use. */
    private fun logGamma(value: Double): Double {
        if (value < 0.5) {
            return ln(Math.PI) - ln(sin(Math.PI * value)) - logGamma(1.0 - value)
        }
        val coefficients = doubleArrayOf(
            0.99999999999980993,
            676.5203681218851,
            -1259.1392167224028,
            771.32342877765313,
            -176.61502916214059,
            12.507343278686905,
            -0.13857109526572012,
            9.9843695780195716e-6,
            1.5056327351493116e-7,
        )
        val shifted = value - 1.0
        var series = coefficients[0]
        for (index in 1 until coefficients.size) {
            series += coefficients[index] / (shifted + index)
        }
        val t = shifted + 7.5
        return 0.9189385332046727 + (shifted + 0.5) * ln(t) - t + ln(series)
    }
}
