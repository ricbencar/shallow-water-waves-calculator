package com.example.weibull.report

import com.example.weibull.solver.WaveInput
import com.example.weibull.solver.WeibullCalculator
import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WeibullReportFormatterTest {
    @Test
    fun reportMatchesReferenceSectionsAndFourDecimalPrecision() {
        val report = WeibullReportFormatter.format(
            WeibullCalculator.calculate(WaveInput(2.5, 5.0, 100.0)),
        )

        val expected = """
            ======================
               INPUT PARAMETERS
            ======================
            Hm0 (m)         : 2.5000
            d (m)           : 5.0000
            Beach slope (m) : 100.0000   (tan(alpha) = 0.0100)

            Distribution Used : B&G

            ===========================
               CALCULATED PARAMETERS
            ===========================
            Free-surface variance m0 (m^2)   : 0.3906
            Mean square wave height Hrms (m) : 1.9344
            Transitional wave height Htr (m) : 2.0400
            Dimensionless H~_tr (Htr/Hrms)   : 1.0546

            =========================================
               DIMENSIONLESS WAVE HEIGHTS (H/Hrms)
            =========================================
            H1/Hrms       : 1.1567
            H2/Hrms       : 1.1102
            H1/3 / Hrms   : 1.3395
            H1/10 / Hrms  : 1.5354
            H1/50 / Hrms  : 1.7213
            H1/100 / Hrms : 1.7870
            H1/250 / Hrms : 1.8650
            H1/1000 /Hrms : 1.9689

            ==================================
               DIMENSIONAL WAVE HEIGHTS (m)
            ==================================
            H1 (m)        : 2.2375
            H2 (m)        : 2.1475
            H1/3 (m)      : 2.5027
            H1/10 (m)     : 2.9701
            H1/50 (m)     : 3.3296
            H1/100 (m)    : 3.4567
            H1/250 (m)    : 3.6077
            H1/1000 (m)   : 3.8086

            =======================
               DIAGNOSTIC RATIOS
            =======================
            (H1/10)/(H1/3)   : 1.1868
            (H1/50)/(H1/3)   : 1.3304
            (H1/100)/(H1/3)  : 1.3812
            (H1/250)/(H1/3)  : 1.4415
            (H1/1000)/(H1/3) : 1.5218

            End of Report
        """.trimIndent() + "\n"

        assertEquals(expected, report)
    }

    @Test
    fun reportAlwaysUsesDotDecimalSeparator() {
        val original = Locale.getDefault()
        try {
            Locale.setDefault(Locale.FRANCE)
            val report = WeibullReportFormatter.format(
                WeibullCalculator.calculate(WaveInput(2.5, 20.0, 100.0)),
            )
            assertTrue(report.contains("Hm0 (m)         : 2.5000"))
            assertFalse(report.contains("2,5000"))
        } finally {
            Locale.setDefault(original)
        }
    }
}
