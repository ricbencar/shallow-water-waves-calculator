package com.example.weibull.ui

import com.example.weibull.solver.DistributionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WeibullViewModelTest {
    @Test
    fun defaultInputsCalculateExpectedResult() {
        val viewModel = WeibullViewModel()

        viewModel.onIntent(WeibullIntent.Calculate)

        val state = viewModel.state.value
        assertNotNull(state.result)
        assertEquals(DistributionType.COMPOSITE_WEIBULL, state.result?.distribution)
        assertTrue(state.report.contains("Distribution Used : B&G"))
        assertFalse(state.calculationFailed)
    }

    @Test
    fun editingInputsClearsStaleResultAndInvalidFieldsAreMarked() {
        val viewModel = WeibullViewModel()
        viewModel.onIntent(WeibullIntent.Calculate)
        viewModel.onIntent(WeibullIntent.WaterDepthChanged("0"))
        viewModel.onIntent(WeibullIntent.Calculate)

        val state = viewModel.state.value
        assertTrue(state.waterDepthHasError)
        assertEquals(null, state.result)
        assertEquals("", state.report)
    }

    @Test
    fun decimalCommaIsAccepted() {
        assertEquals(2.5, parseDecimal("2,5") ?: Double.NaN, 0.0)
    }
}
