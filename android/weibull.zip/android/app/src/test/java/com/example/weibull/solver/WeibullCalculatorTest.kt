package com.example.weibull.solver

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class WeibullCalculatorTest {
    @Test
    fun defaultInputsMatchCompositeWeibullReference() {
        val result = WeibullCalculator.calculate(WaveInput(2.5, 5.0, 100.0))

        assertEquals(DistributionType.COMPOSITE_WEIBULL, result.distribution)
        assertClose(0.390625, result.freeSurfaceVariance)
        assertClose(1.934375, result.hrms)
        assertClose(2.04, result.transitionHeightMeters)
        assertClose(1.054604200323102, result.normalizedTransitionHeight)
        assertClose(1.156695416114436, result.lowerScaleToHrms)
        assertClose(1.110155138027455, result.upperScaleToHrms)

        assertSeries(
            doubleArrayOf(
                1.339521443581,
                1.535414557639,
                1.721293216091,
                1.786991051842,
                1.865044858516,
                1.968880469286,
            ),
            result.statistics.map { it.ratioToHrms }.toDoubleArray(),
        )
        assertSeries(
            doubleArrayOf(
                2.502689342379,
                2.970067534933,
                3.329626564875,
                3.456710815907,
                3.607696148191,
                3.808553157774,
            ),
            result.statistics.map { it.heightMeters }.toDoubleArray(),
        )
        assertSeries(
            doubleArrayOf(
                1.186750382734,
                1.330419444592,
                1.381198520077,
                1.441527754604,
                1.521784223588,
            ),
            result.diagnosticRatios.map { it.value }.toDoubleArray(),
        )
    }

    @Test
    fun deepWaterInputsUseExactRayleighConstants() {
        val result = WeibullCalculator.calculate(WaveInput(2.5, 20.0, 100.0))

        assertEquals(DistributionType.RAYLEIGH, result.distribution)
        assertClose(0.390625, result.freeSurfaceVariance)
        assertClose(1.74453125, result.hrms)
        assertClose(8.16, result.transitionHeightMeters)
        assertClose(4.677474249888044, result.normalizedTransitionHeight)
        assertEquals(0.0, result.lowerScaleToHrms, 0.0)
        assertEquals(0.0, result.upperScaleToHrms, 0.0)
        assertEquals(0.0, result.lowerScaleMeters, 0.0)
        assertEquals(0.0, result.upperScaleMeters, 0.0)
        assertSeries(
            doubleArrayOf(
                2.502689342379,
                3.181835683423,
                3.900283449937,
                4.170583430896,
                4.502543056244,
                4.962088976438,
            ),
            result.statistics.map { it.heightMeters }.toDoubleArray(),
        )
        assertSeries(
            doubleArrayOf(
                1.43459129343733,
                1.82389147997368,
                2.23572002504220,
                2.39066134865529,
                2.58094720644532,
                2.84436806531180,
            ),
            result.statistics.map { it.ratioToHrms }.toDoubleArray(),
        )
        assertSeries(
            doubleArrayOf(
                1.27136661731968,
                1.55843691180178,
                1.66644072049759,
                1.79908188363619,
                1.98270272399088,
            ),
            result.diagnosticRatios.map { it.value }.toDoubleArray(),
        )
    }

    @Test
    fun compositeResultsAreIndividuallyCappedAtRayleighLimits() {
        val result = WeibullCalculator.calculate(WaveInput(1.0, 5.0, 250.0))

        assertEquals(DistributionType.COMPOSITE_WEIBULL, result.distribution)
        assertSeries(
            doubleArrayOf(
                1.001075736952,
                1.272734273369,
                1.560113379975,
                1.668233372359,
                1.800855226268,
                1.939478066635,
            ),
            result.statistics.map { it.heightMeters }.toDoubleArray(),
        )
    }

    @Test
    fun branchSwitchIsStrictlyGreaterThanThreshold() {
        val boundary = WeibullCalculator.calculate(
            WaveInput(2.076334925632012, 10.0, 100.0),
        )
        val justAboveThreshold = WeibullCalculator.calculate(
            WaveInput(2.0763349256320116, 10.0, 100.0),
        )

        assertEquals(DistributionType.COMPOSITE_WEIBULL, boundary.distribution)
        assertEquals(2.75, boundary.normalizedTransitionHeight, 0.0)
        assertEquals(DistributionType.RAYLEIGH, justAboveThreshold.distribution)
    }

    @Test
    fun stronglyDepthLimitedCaseMatchesReference() {
        val result = WeibullCalculator.calculate(WaveInput(4.0, 5.0, 20.0))

        assertEquals(DistributionType.COMPOSITE_WEIBULL, result.distribution)
        assertSeries(
            doubleArrayOf(
                4.004302947807,
                5.050064708552,
                5.661430055095,
                5.877513926454,
                6.134237280086,
                6.475758435288,
            ),
            result.statistics.map { it.heightMeters }.toDoubleArray(),
        )
    }

    @Test
    fun invalidInputsAreRejected() {
        listOf(
            0.0,
            -1.0,
            Double.NaN,
            Double.POSITIVE_INFINITY,
            Double.NEGATIVE_INFINITY,
        ).forEach { invalid ->
            assertThrows(InvalidWaveInputException::class.java) {
                WeibullCalculator.calculate(WaveInput(invalid, 5.0, 100.0))
            }
            assertThrows(InvalidWaveInputException::class.java) {
                WeibullCalculator.calculate(WaveInput(2.5, invalid, 100.0))
            }
            assertThrows(InvalidWaveInputException::class.java) {
                WeibullCalculator.calculate(WaveInput(2.5, 5.0, invalid))
            }
        }
    }

    private fun assertSeries(expected: DoubleArray, actual: DoubleArray) {
        assertEquals(expected.size, actual.size)
        expected.indices.forEach { index -> assertClose(expected[index], actual[index]) }
    }

    private fun assertClose(expected: Double, actual: Double) {
        assertEquals(expected, actual, 2.0e-9)
    }
}
